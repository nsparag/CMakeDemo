#include "../include/functionalities.h"

bool compareByPriority(const Sensor& obj1, const Sensor& obj2){
    return obj1.getPriority() < obj2.getPriority();
}