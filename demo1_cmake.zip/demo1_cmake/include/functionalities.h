
#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include "Sensor.h"

bool compareByPriority(const Sensor&, const Sensor&);

#endif // FUNCTIONALITIES_H
