#include "../include/Sensor.h"
#include <iostream>


Sensor::Sensor(std::string name, int priority, double reading):name(name), priority(priority), reading(reading){}

std::string Sensor::getName() const { return name; }
int Sensor::getPriority() const { return priority; }
double Sensor::getReading() const { return reading; }

void Sensor::setName(std::string name) { this->name = name; }
void Sensor::setPriority(int priority) { this->priority = priority; }
void Sensor::setReading(double reading) { this->reading = reading; }


void Sensor::display() const { std::cout << "Sensor: " << name << ", Priority: " << priority << ", Reading: " << reading << std::endl;}