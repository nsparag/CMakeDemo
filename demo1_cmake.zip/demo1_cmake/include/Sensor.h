
#ifndef SENSOR_H
#define SENSOR_H

#include <string>

class Sensor{
    private:
        std::string name;
        int priority;
        double reading;
    public:
        Sensor() = default;
        Sensor(std::string name, int priority, double reading);
        

        Sensor(const Sensor&) = default;    // copy constructor
        Sensor(Sensor&&)= default;   // move constructor
        Sensor& operator=(const Sensor&) = default; // copy assignment operator
        Sensor& operator=(Sensor&&) = default;    // move assignment operator
        ~Sensor()= default;

    
        std::string getName() const;
        int getPriority() const;
        double getReading() const;

        void setName(std::string name);
        void setPriority(int priority);
        void setReading(double reading);

        void display() const;
};

#endif // SENSOR_H
