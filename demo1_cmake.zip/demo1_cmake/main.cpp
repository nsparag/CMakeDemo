#include <iostream>
#include <vector>
#include <algorithm>
#include "../demo1/include/Sensor.h"
#include "../demo1/include/functionalities.h"

int main(){
    std::vector<Sensor> sensors = {
        {"speed", 2, 70.2},
        {"temperature", 3, 25.5},
        {"humidity", 1, 60.0},
        {"pressure", 4, 1013.25},
        {"altitude", 5, 1000.0},
        {"light", 6, 50.0},
        {"sound", 7, 80.0}
    };

    std::cout << "List of sensors:\n";
    std::for_each(sensors.begin(),sensors.end(),[](const Sensor& sensor) {sensor.display();});

    std::cout << "\n\nList of sensors: after sorting\n";
    std::sort(sensors.begin(),sensors.end(),compareByPriority);

    std::for_each(sensors.begin(),sensors.end(),[](const Sensor& sensor) {sensor.display();});

    return 0;
}